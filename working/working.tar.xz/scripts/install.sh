#!/bin/sh
# bootstrap webmin after initialising environment for DSM
# (c) https://github.com/gnadelwartz
export PATH=$PATH:/opt/bin/:/opt/sbin

# get path to perl executable
PERL=`which perl`
if [ -x /opt/bin/perl ]
then
# use ipkg perl if installed
PERL="/opt/bin/perl"
/bin/ln -sf /opt/bin/cpan /bin/cpan 2>&1 1>/dev/null
fi

# where to download webmin
webmin_version="2.651"
webmin="webmin-${webmin_version}"
tarext="tar.gz"
# configuration files
MINICONF=/var/packages/webmin/target/etc/miniserv.conf

# download webmin from GitHub releases (primary), fallback to builds.webmin.dev
/bin/echo "download webmin ${webmin_version} release ...<br>"
/bin/wget -nv "https://github.com/webmin/webmin/releases/download/${webmin_version}/${webmin}.${tarext}"
if [ ! -f "$webmin.$tarext" ] ; then
    /bin/echo "Retrying from builds.webmin.dev ...<br>"
    /bin/wget -nv "https://builds.webmin.dev/webmin-latest.${tarext}" -O "$webmin.$tarext"
fi

# unpack and install
if [ -f "$webmin.$tarext" ]
then
    # echo "<br>unpacking webmin ..."
    /bin/tar -xzf "$webmin.$tarext"
    /bin/rm "$webmin.$tarext"

    /bin/echo "<br>Start installation of `/bin/ls -d webmin*` ...<br>"
    
    cd webmin*
    #get enviroanment from config file and prepare non interactive install
    install_dir=`/bin/grep "^root=" ${MINICONF}| /bin/sed 's/.*root=//'`
    config_dir=`/bin/grep "env_WEBMIN_CONFIG=" ${MINICONF}| /bin/sed 's/.*_WEBMIN_CONFIG=//'`
    var_dir=`/bin/grep "env_WEBMIN_VAR=" ${MINICONF}| /bin/sed 's/.*_WEBMIN_VAR=//'`
    atboot="NO"
    makeboot="NO"
    nouninstall="YES"
    /bin/echo $PERL >$config_dir/perl-path
    /bin/echo $var_dir >$config_dir/var-path
    export config_dir atboot nouninstall makeboot nostart
    # run install script, output only Errors and important messages
/bin/echo '<div class="list">Move mouse here to see all messages ...<br>'
    ./setup.sh $install_dir | /bin/sed -e '/done/d' -e '/^$/d' -e 's/$/<br>/' -e '/scripts/d' -e '/files/d'
/bin/echo '</div><style> .list {height: 9em; overflow-y: hidden;} .list:hover {height: auto;} #sds-desktop div.active-win {top: 10px !important;}</style>'
    cd ..
    # cp additional man pages
    /bin/mkdir -p /opt/man/man1
    /bin/cp -L ../man/man1/* /opt/man/man1/ 2>/dev/null || true
# add local IP to /etc/hosts
IP=`/bin/sed -n 's/IPADDR=//p' /etc/dhclient/ipv4/dhcpcd-eth0.info 2>/dev/null`
if [ -n "${IP}" ] ; then
    /bin/grep -q "${IP}" /etc/hosts 
    if [ $? -ne 0 ] ; then
        /bin/sed  -i "1i ${IP} `hostname`" /etc/hosts
    fi
fi
    /bin/echo "Installation of Webmin was successful!"
    /bin/rm -rf webmin*
else
   /bin/echo "<p>Download of webmin failed!<p>"
   exit 1
fi
